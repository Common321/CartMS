package com.example.order.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.order.Dto.CartDTO;
import com.example.order.Entity.Cart;
import com.example.order.Service.CartService;


@RestController
@RequestMapping(value = "/Cart")
public class CartController {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	CartService cartService;
	
	
	@GetMapping(value="/orders", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<CartDTO> getAllCarts() {
		logger.info("Fetching all Carts");
		return cartService.getAllCarts();
	}
	
	@GetMapping(value = "/orders/{buyerId}",produces = MediaType.APPLICATION_JSON_VALUE)
	public List<CartDTO> getSpecificCart(@PathVariable Integer buyerId) {
		logger.info("Fetching details of Cart {}",buyerId);
		return cartService.getSpecificCart(buyerId);
	}
}
