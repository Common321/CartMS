package com.example.order.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.order.Entity.Cart;

public interface CartRepository extends JpaRepository<Cart,Integer>{
	List<Cart> findAll();
	List<Cart> findByBuyerId(Integer buyerId);
}
