package com.example.order.Entity;

import java.io.Serializable;

@SuppressWarnings("serial")
public class KeyComp implements Serializable {
		Integer buyerId;
		Integer prodId;
}
