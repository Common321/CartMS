package com.example.order.Service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.order.Dto.CartDTO;
import com.example.order.Entity.Cart;
import com.example.order.Repository.CartRepository;


@Service
public class CartService {
Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	CartRepository cartRepo;
	
	public List<CartDTO> getAllCarts() {
		List<Cart> carts = cartRepo.findAll();
		List<CartDTO> cartDtos = new ArrayList<CartDTO>();
		for (Cart cart : carts) {
			CartDTO cartDto = CartDTO.valueOf(cart);
			cartDtos.add(cartDto);
		}
		logger.info("cart details : {}", carts);
		return cartDtos;
	}

	
	public List<CartDTO> getSpecificCart(int buyerId) {
		logger.info("order details : {}", buyerId);
		List<Cart> carts = cartRepo.findByBuyerId(buyerId);
		List<CartDTO> cartDtos = new ArrayList<CartDTO>();
		for (Cart cart : carts) {
			CartDTO cartDto = CartDTO.valueOf(cart);
			cartDtos.add(cartDto);
		}
		logger.info("cart details : {}", carts);
		return cartDtos;
	}
}
