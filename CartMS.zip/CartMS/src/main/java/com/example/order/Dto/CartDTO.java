package com.example.order.Dto;

import com.example.order.Entity.Cart;


public class CartDTO {
	Integer buyerId;
	Integer prodId;
	Integer quantity;
	
	public Integer getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(Integer buyerId) {
		this.buyerId = buyerId;
	}
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	
	
	public static CartDTO valueOf(Cart cart)
	{
		CartDTO cartDto = new CartDTO();
		cartDto.setBuyerId(cart.getBuyerId());
		cartDto.setProdId(cart.getProdId());
		cartDto.setQuantity(cart.getQuantity());
		return cartDto;
	}
}
